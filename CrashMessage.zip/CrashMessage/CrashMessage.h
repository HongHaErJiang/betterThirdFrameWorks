//
//  CrashMessage.h
//  MiFengBangBangProject
//
//  Created by 朱公园 on 2017/11/2.
//  Copyright © 2017年 yixiuge. All rights reserved.
//崩溃信息统计并上传

#import <Foundation/Foundation.h>
#import <CrashReporter/CrashReporter.h>
@interface CrashMessage : NSObject

+ (CrashMessage*)sharedInstance;

@end
