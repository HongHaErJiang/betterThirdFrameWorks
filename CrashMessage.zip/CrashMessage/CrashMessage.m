//
//  CrashMessage.m
//  MiFengBangBangProject
//
//  Created by 朱公园 on 2017/11/2.
//  Copyright © 2017年 yixiuge. All rights reserved.
//

#import "CrashMessage.h"

#define CRASHMESSAGE @"CrashMessage"

@implementation CrashMessage


//获取当前可用内存
static double availableMemory () {
    
    vm_statistics_data_t vmStats;
    mach_msg_type_number_t infoCount = HOST_VM_INFO_COUNT;
    kern_return_t kernReturn = host_statistics(mach_host_self(),
                                               HOST_VM_INFO,
                                               (host_info_t)&vmStats,
                                               &infoCount);
    
    if (kernReturn != KERN_SUCCESS) {
        return NSNotFound;
    }
    
    return ((vm_page_size *vmStats.free_count) / 1024.0) / 1024.0;
}

//程序崩溃回调函数
static void post_crash_callback (siginfo_t *info, ucontext_t *uap, void *context) {
    NSLog(@"post crash callback: signo=%d, uap=%p, context=%p", info->si_signo, uap, context);
    
    __block NSString * netWorkStatus = @"";
    
    [PPNetworkHelper networkStatusWithBlock:^(PPNetworkStatusType status) {
        switch (status) {
                /** 未知网络*/
            case PPNetworkStatusUnknown:
            {
                netWorkStatus = @"未知网络";
            }
                break;
                /** 无网络*/
            case PPNetworkStatusNotReachable:
            {
                netWorkStatus = @"未连接网络";
            }
                break;
                
                /** 手机网络*/
            case PPNetworkStatusReachableViaWWAN:
            {
                netWorkStatus = @"手机蜂窝网";
            }
                break;
                /** WIFI网络*/
            case PPNetworkStatusReachableViaWiFi:
            {
                netWorkStatus = @"WIFI网络";
            }
                break;
            default:
                break;
        }
    }];
    
    NSDictionary * dataDict = [NSDictionary dictionaryWithObjectsAndKeys:@"你们有崩溃信息了",@"userName",netWorkStatus,@"NetWorkStatus", [NSString stringWithFormat:@"%lf",availableMemory()],@"avalableMemory",nil];
    [[NSUserDefaults standardUserDefaults] setObject:dataDict forKey:CRASHMESSAGE];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

+ (instancetype)sharedInstance {
    static id sharedInstance;
    static dispatch_once_t pred;
    dispatch_once(&pred, ^{
        sharedInstance = [[self alloc] init];
        [self initialize];
    });
    return sharedInstance;
}

-(void)initialize{
    
    //    1.初始化崩溃记录
    //PLCrashReporterSymbolicationStrategyAll 作用是将解析符号可视化
    PLCrashReporterConfig * config = [[PLCrashReporterConfig alloc]initWithSignalHandlerType:PLCrashReporterSignalHandlerTypeBSD symbolicationStrategy:PLCrashReporterSymbolicationStrategyAll];
    PLCrashReporter * crashReporter = [[PLCrashReporter alloc]initWithConfiguration:config];
    
    
    //    2.启动崩溃日志记录
    NSError * EnableError;
    if (![crashReporter enableCrashReporterAndReturnError:&EnableError]) {
        NSLog(@"不能够启动崩溃日志记录功能，Reason:%@",EnableError);
    }
    
    // 3.设置崩溃时的回调，存储其他相关自定义信息
    PLCrashReporterCallbacks *callbacks = malloc(sizeof(PLCrashReporterCallbacks));
    bzero(callbacks, sizeof(PLCrashReporterCallbacks));
    callbacks->version = 0;
    callbacks->context = NULL;
    callbacks->handleSignal = post_crash_callback;
    [[PLCrashReporter sharedReporter] setCrashCallbacks:callbacks];
    
    
    //4.每次APP重新启动时，获取上次崩溃数据
    //判断如果存在崩溃信息
    if ([crashReporter hasPendingCrashReport]) {
        
        NSError * DataError;
        NSData * crashData = [crashReporter loadPendingCrashReportDataAndReturnError:&DataError];
        if (crashData==nil) {
            NSLog(@"无法获取崩溃记录数据,Reason:%@",DataError);
            return;
        }
        
        NSError * parseError;
        PLCrashReport * reportData = [[PLCrashReport alloc]initWithData:crashData error:&parseError];
        if (reportData==nil) {
            NSLog(@"不能解析崩溃数据,Reason%@",parseError);
            return;
        }
        
        //发生异常时间
        NSDateFormatter * dateFormatter =[[NSDateFormatter alloc]init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        NSString * date = [dateFormatter stringFromDate:reportData.systemInfo.timestamp];
        
        NSMutableDictionary * iOSCrashDict = @{@"currentDate":date,
                                               @"APPVersion":reportData.applicationInfo.applicationVersion,
                                               @"APPbuild":reportData.applicationInfo.applicationIdentifier,
                                               @"IphoneModel":reportData.machineInfo.modelName,
                                               @"IphoneVersion":reportData.systemInfo.operatingSystemVersion,
                                               @"IphoneBuild":reportData.systemInfo.operatingSystemBuild,
                                               @"UUID":(__bridge NSString *)reportData.uuidRef
                                               };
        
        
        //将崩溃数据解析成文本格式
        NSString * crashText = [PLCrashReportTextFormatter stringValueForCrashReport:reportData withTextFormat:PLCrashReportTextFormatiOS];
        NSLog(@"%@",crashText);
        
        NSDictionary * dict = [[NSUserDefaults standardUserDefaults] objectForKey:CRASHMESSAGE];
        showHUD(dict[@"userName"], 10);
        [iOSCrashDict addEntriesFromDictionary:dict];
        
        //将上次崩溃的信息上传到后台服务器
        ///
        
        
        
        
        
        //将本地的崩溃数据清除掉
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:CRASHMESSAGE];
        [[NSUserDefaults standardUserDefaults] synchronize];
        [crashReporter purgePendingCrashReport];
        
    }
}




@end
