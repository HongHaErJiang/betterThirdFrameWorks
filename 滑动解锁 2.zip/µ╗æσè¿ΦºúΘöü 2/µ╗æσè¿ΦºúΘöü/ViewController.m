//
//  ViewController.m
//  滑动解锁
//
//  Created by BWP on 16/4/27.
//  Copyright © 2016年 BWP. All rights reserved.
//

#import "ViewController.h"
#import "LockView.h"

@interface ViewController ()


@property (weak, nonatomic) IBOutlet LockView *lockView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
}






@end
