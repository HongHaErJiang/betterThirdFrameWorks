//
//  SignalHandler.h
//  
//
//  Created by 朱公园 on 2017/11/2.
//  Copyright © 2017年 yixiuge. All rights reserved.

#import <Foundation/Foundation.h>

@interface SignalHandler : NSObject

//保存异常信息
+(void)saveCreash:(NSString *)exceptionInfo;

@end

void InstallSignalHandler(void);
