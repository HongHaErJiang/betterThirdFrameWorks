//
//  UncaughtExceptionHandler.h
//
//
//  Created by 朱公园 on 2017/11/2.
//  Copyright © 2017年 yixiuge. All rights reserved.
#import <Foundation/Foundation.h>

@interface UncaughtExceptionHandler:NSObject

@end


void InstallUncaughtExceptionHandler(void);


