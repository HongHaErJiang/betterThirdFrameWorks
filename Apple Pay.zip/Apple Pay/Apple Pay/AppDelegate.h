//
//  AppDelegate.h
//  Apple Pay
//
//  Created by 朱公园 on 2017/9/7.
//  Copyright © 2017年 朱公园. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

