//
//  ViewController.m
//  Apple Pay
//
//  Created by 朱公园 on 2017/9/7.
//  Copyright © 2017年 朱公园. All rights reserved.
//

#import "ViewController.h"
#import <PassKit/PassKit.h>
@interface ViewController ()<PKPaymentAuthorizationViewControllerDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //前言说明:==================================
    //    ==>>Apple Pay共分为线上支付跟线下支付两种模式，简单来说线上支付就是通过手机内的APP进行消费，线下支付就是在实体店进行消费。
    //
    //    ==>>线下支付支持的机型有：iPhone 6s、iPhone 6s Plus、iPhone 6、iPhone 6 Plus和Apple Watch；
    //
    //    ==>>线上支付支持的机型有：iPhone 6s、iPhone 6s Plus、iPhone 6、iPhone 6 Plus、iPad Air 2、iPad mini 3、iPad mini 4以及iPad Pro。
    //    ==>>除了硬件支持要求外，Apple Pay对系统也是有要求的，仅当iOS系统升级至iOS 9.2或者更高版本才能够使用Apple Pay。
    //  ==>>注意PKPaymentAuthorizationViewControllerDelegate 和PKPaymentAuthorizationControllerDelegate区别，主要在于前者针对继承于UIViewController的PKAddPaymentPassViewController,而后者是继承NSObject的PKPaymentAuthorizationController，实现的present方式是不一样的,当前代码是基于PKPaymentAuthorizationViewControllerDelegate对应的方法实现的
    
    //    在 Xcode 7.0 及其后的版本中，你可以在模拟器中测试支付授权视图控制器。这些版本的模拟器提供了支持所有支付网络的虚拟卡，它会以纯文本的方式返回虚拟支付数据。在设备上时，这些数据会使用商户 ID 进行加密。
    //
    //    虽然模拟器可以方便快捷地测试支付代码，但是你仍然需要在物理设备上测试你的支付功能。
    //
    //    如果你使用的是较早版本的 Xcode，那么你就只能在物理设备上测试你的支付功能了。
    
    // 详细文档可以参考 http://wiki.jikexueyuan.com/project/apple-pay/
    
    
    //PKPaymentButton是继承于UIButton的带有ApplePay支付特征的按钮,可以根据自己项目需要决定是否使用
    PKPaymentButton * button = [PKPaymentButton buttonWithType:PKPaymentButtonTypePlain style:PKPaymentButtonStyleBlack];
    [button addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    button.frame =CGRectMake(100, 100, 100, 30);
    [self.view addSubview:button];
    
    
    
}

- (void)click:(PKPaymentButton * )sender{
    
    //判断当前设备是否支持Apple Pay
    if (![PKPaymentAuthorizationViewController canMakePayments]) {
        NSLog(@"当前设备不支持 Apple Pay");
    }
    /**1.方法解释
     + (BOOL)canMakePaymentsUsingNetworks:(NSArray*)supportedNetworks capabilities:
     *(PKMerchantCapability)capabilties;和 + (BOOL)canMakePaymentsUsingNetworks:(NSArray*)supportedNetworks;的区别在于后者除设备、网络不支持等情况下会返回NO，用户未在Wallet中绑卡的情况下也会返回NO
     
     如果 canMakePayments 返回 YES，但 canMakePayementsUsingNetworks: 返回 NO，则表示设备支持 Apple Pay，但是用户并没有为任何请求的支付网络添加银行卡。你可以选择显示一个支付设置按扭，引导用户添加银行卡。如果用户点击该按扭，则开始设置新的银行卡流程
     */
    //2.设置支持卡的类型
    /**
     *  对支付卡类别的限制
     *  PKPaymentNetworkChinaUnionPay  银联卡
     *  PKPaymentNetworkVisa  国际卡
     *  PKPaymentNetworkMasterCard 万事达卡 国际卡
     *  PKPaymentNetworkDiscover 美国流行的信用卡
     */
    
    else if(![PKPaymentAuthorizationViewController canMakePaymentsUsingNetworks:@[PKPaymentNetworkVisa,PKPaymentNetworkChinaUnionPay]]){
        //进入设置银行卡界面
        [[PKPassLibrary alloc] openPaymentSetup];
        
    }else{
        
        //如果上述条件都满足，则开始创建支付请求
        PKPaymentRequest * request = [[PKPaymentRequest alloc]init];
        //开发者中心申请的merchant IDs
        request.merchantIdentifier = @"merchant.com.sweatelephant";
        //设置国家代码,CN代表中国
        request.countryCode = @"CN";
        // 设置支付货币形式,CNY代表人民币
        request.currencyCode = @"CNY";
        //设置支付标准,3DS支付方式是必须支持的，其他方式可选
        request.merchantCapabilities=PKMerchantCapability3DS;
        //设置支持卡类型
        request.supportedNetworks=@[PKPaymentNetworkChinaUnionPay,PKPaymentNetworkVisa];
        
        // 设置商品信息
        PKPaymentSummaryItem * itemOne = [PKPaymentSummaryItem summaryItemWithLabel:@"衣服" amount:[NSDecimalNumber decimalNumberWithString:@"0.01"]];
        
        PKPaymentSummaryItem * itemTwo = [PKPaymentSummaryItem summaryItemWithLabel:@"鞋子" amount:[NSDecimalNumber decimalNumberWithString:@"0.01"]];
        
        PKPaymentSummaryItem * summary = [PKPaymentSummaryItem summaryItemWithLabel:@"杭州唛客网络技术有限公司" amount:[NSDecimalNumber decimalNumberWithString:@"0.02"]];
        // 特别注意:paymentSummaryItems数组最后一个元素的金额一定是总金额，Label一般写成收款公司
        request.paymentSummaryItems = @[itemOne,itemTwo,summary];
        
        
        
        // 以上参数都是必须的
        //以下参数不是必须的
        
        
        //        //设置收据内容,决定是否在弹出窗显示
        request.requiredBillingAddressFields = PKAddressFieldAll; //PKAddressFieldAll表示邮送地址，电话，Email，姓名，当然也可以根据你的需要设置
        
        //设置送货内容,决定是否在弹出窗显示，当然也可以根据你的需要设置
        request.requiredShippingAddressFields=PKAddressFieldAll;
        
        
        //设置送货方式,可以设置多个送货方式，默认展示第一个
        PKShippingMethod * methodOne = [PKShippingMethod summaryItemWithLabel:@"顺丰快递" amount:[NSDecimalNumber decimalNumberWithString:@"10"]];
        methodOne.identifier = @"顺丰速运"; //标识符，用来系统区分不同运送方式，不展示
        methodOne.detail= @"顺丰快递同城6小时到达，跨省12小时";
        
        PKShippingMethod * methodTwo = [PKShippingMethod summaryItemWithLabel:@"菜鸟快递" amount:[NSDecimalNumber decimalNumberWithString:@"20"]];
        methodTwo.identifier = @"菜鸟速运";
        methodTwo.detail= @"菜鸟快递同城6小时到达，跨省12小时";
        
        request.shippingMethods = @[methodOne,methodTwo];
        
        
        
        //如果已有最新账单信息以及配送联系信息，你可以直接为支付请求设置这些值。 Apple Pay 会默认使用这些信息。但是，用户仍然可以选择在本次支付中使用其它联系信息。
        //        PKContact * contact = [[PKContact alloc]init];
        //        contact.emailAddress = @"8967679899@qq.com";
        //
        //
        //        CNPhoneNumber * phone = [[CNPhoneNumber alloc]initWithStringValue:@"18612227896"];
        //        contact.phoneNumber = phone;
        //
        //        NSPersonNameComponents * name = [[NSPersonNameComponents alloc]init];
        //        name.givenName = @"john";
        //        name.familyName = @"APPLE";
        //
        //        contact.name = name;
        //
        //        CNMutablePostalAddress * address =[[CNMutablePostalAddress alloc]init];
        //        address.street = @"街道地址";
        //        address.city = @"城市名称";
        //        address.state = @"外国的州，中国的省";
        //        address.postalCode =@"345123";//邮编
        //        contact.postalAddress =address;
        //
        //        request.shippingContact = contact;
        //        request.shippingContact = contact;
        
        PKPaymentAuthorizationViewController * payVc = [[PKPaymentAuthorizationViewController alloc]initWithPaymentRequest:request];
        payVc.delegate = self; //实现代理
        [self presentViewController:payVc animated:YES completion:nil];
        
        
    }
    
    
    
    
}

/**
 为了保护用户隐私，提供给方法 paymentAuthorizationViewController:didSelectShippingContact:completion: 的配送信息是经过匿名化处理后的数据。返回的 contact 包含了计算配送费用的所有信息同时隐藏了用户的敏感信息。只有在用户授权支付后，你才能得到用户完整的配送信息。此外， contact 中的数据会随着国家的不同而不同，同时还会随着版本的更新而变化。请仔细测试你的应用程序。
 */

//当用户更新了运送方式后，该方法会调用，处理因运送方式不同导致比如价格等的变化
//- (void)paymentAuthorizationViewController:(PKPaymentAuthorizationViewController *)controller didSelectShippingMethod:(PKShippingMethod *)shippingMethod completion:(void (^)(PKPaymentAuthorizationStatus, NSArray<PKPaymentSummaryItem *> * _Nonnull))completion{
//    //    self.selectedShippingMethod = shippingMethod; //存储重新获取的配送方式
//    //    [self updateShippingCost]; //更新业务请求
//    //    completion(PKPaymentAuthorizationStatusSuccess, self.summaryItems);
//    
//}



//当用户更新变化送货地址和联系方式后，该方法会调用，处理因送货地址发生的变化导致价格变化
//- (void)paymentAuthorizationViewController:(PKPaymentAuthorizationViewController *)controller didSelectShippingContact:(PKContact *)contact completion:(void (^)(PKPaymentAuthorizationStatus, NSArray<PKShippingMethod *> * _Nonnull, NSArray<PKPaymentSummaryItem *> * _Nonnull))completion{
//    
//    //    self.selectedContact = contact;  //重新选择后的contact
//    //    [self updateShippingCost];   // 更新数据请求
//    //    NSArray *shippingMethods = [self shippingMethodsForContact:contact]; // 根据变化的contact，重新获取配送方式列表
//    //
//    //    //self.summaryItems 是商品信息数组
//    //    completion(PKPaymentAuthorizationStatusSuccess, shippingMethods, self.summaryItems);
//}




//支付授权流程说明
//当用户授权一个支付请求时，支付框架的 Apple 服务器与安全模块会协作创建一个支付令牌。你可以在委托方法 paymentAuthorizationViewController:didAuthorizePayment:completion: 中将支付信息以及其它你需要处理的信息，例如配送地址和购物车标识符，一起发送至你的服务器。这个过程如下所示：
//
//支付框架将支付请求发送至安全模块。只有安全模块会访问令牌化后的设备相关的支付卡号。
//安全模块将特定卡的支付数据和商家信息一起加密(加密后的数据只有 Apple 可以访问)，然后将加密后的数据发送至支付框架。支付框架再将这些数据发送至 Apple 的服务器。
//Apple 服务器使用商家标识证书将这些支付数据重新加密。这些令牌只能由你以及那些与你共享商户标识证书的人读取。随后服务器生成支付令牌再将其发送至设备。
//支付框架调用 paymentAuthorizationViewController:didAuthorizePayment:completion: 方法将令牌发送至你的委托。你在委托方法中再将其发送至你的服务器。
//在服务器上的处理操作取决于你是自己处理支付还是使用其它支付平台。不过，在两种情况下服务器都得处理订单再将处理结果返回给设备。在设备上，委托再将处理结果传入完成处理方法中
- (void)paymentAuthorizationViewController:(PKPaymentAuthorizationViewController *)controller didAuthorizePayment:(PKPayment *)payment completion:(void (^)(PKPaymentAuthorizationStatus))completion{
    /**
     *  在这个代理方法内部,需支付信息应发送给服务器/第三方的SDK（银联SDK/易宝支付SDK/易智付SDK等）
     *  再根据服务器返回的支付成功与否进行不同的block显示
     *  我这里是直接返回支付成功的结果
     */
    
    
    //此处发送 PKPAyment 下的token billingContact 、shippingContact、shippingAddress等信息到您的服务器，根据服务器返回的状态决定改如何处理
    
    //PKPayment下paymentData数据格式如下 ：
    /*{
     "data" : "....",
     "header" :    {
     "publicKeyHash" : "....",
     "transactionId" : "......",
     "wrappedKey" : "......"
     },
     "signature" : ".....";
     "version" : "RSA_v1"
     }
     */
    
    
    //后台处理数据步骤如下：
    //    1.首先解密前需要对signature验签，验证此次支付的正确和安全性
    //    2.用商户私钥（merchant ID导出的p12文件）解密wrappedKey得到对称秘钥，用对称秘钥AES解密data就得到支付信息了
    //    3.解密得到的支付信息中包含卡号(可卡bin的虚拟卡号)、支付金额、银行卡密码等信息。这个时候就可以利用这些信息开始发起支付并扣款了。
    //    4.得到支付结果后，利用代理方法中的complete块回调给苹果，苹果根据相应的支付状态展示给用户。
    //    5.目前苹果对于支付状态的处理只有支付成功、失败、无效账单地址、无效邮寄地址、无效联系方式、以及iOS9.2开始支持的银行卡密码错误、密码锁定、未输入密码。
    /*
     PKPaymentAuthorizationStatusSuccess, // 支付成功
     PKPaymentAuthorizationStatusFailure, //支付失败
     
     PKPaymentAuthorizationStatusInvalidBillingPostalAddress,  // 无效账单地址     PKPaymentAuthorizationStatusInvalidShippingPostalAddress, // 无效邮寄地址     PKPaymentAuthorizationStatusInvalidShippingContact,       // 无效联系方式
     PKPaymentAuthorizationStatusPINRequired NS_ENUM_AVAILABLE_IOS(9_2),  //iOS9.2开始支持的银行卡未输入密码
     PKPaymentAuthorizationStatusPINIncorrect NS_ENUM_AVAILABLE_IOS(9_2), // iOS9.2开始支持的银行卡密码错误
     PKPaymentAuthorizationStatusPINLockout NS_ENUM_AVAILABLE_IOS(9_2)    // iOS9.2开始支持的银行卡密码锁定     */
    
    
    //支付结果回调给苹果
    completion(PKPaymentAuthorizationStatusSuccess);
    
    
}

- (void)paymentAuthorizationViewControllerDidFinish:(PKPaymentAuthorizationViewController *)controller{
    //支付页面关闭
    //点击支付/取消按钮调用该代理方法
    [controller dismissViewControllerAnimated:YES completion:nil];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
